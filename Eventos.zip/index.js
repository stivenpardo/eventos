var express = require('express');
var bodyParser = require('body-parser')
const eventos = require("./datos.js")
var  connect = require("./connect/connect.js")
var app = express();
var MyConnect = new connect("eventos")
let ev = new eventos(MyConnect.getConnect())
// create application/json parser 
var jsonParser = bodyParser.json()


app.get('/', function (req, res) {
  res.send('Hello World!');
});

app.get('/eventos',(req,res)=>{
	let gEvento = ev.getEvento()
	gEvento.then(resp=>{
		res.send(resp)
	})
});

app.get('/eventos/:id',(req,res)=>{
	let ge = ev.getEventoById(req.params.id)
	ge.then(resp=>{
		res.send(resp)
	})
});

app.post('/eventos', jsonParser,(req, res) => {
  ev.setEvento(req.body) 
  res.send(req.body)
});

app.put('/eventos', jsonParser,(req, res) => {
  ev.updateEvento(req.body) 
  res.send(req.body)
});

app.delete('/eventos/delete/:id',(req,res)=>{
	let deleteEvento = ev.deleteEvento(req.params.id)
	deleteEvento.then(resp=>{
		res.send(resp)
	});
})

app.listen(3000, function () {
  console.log('Example app listening on port 3000!');
});
