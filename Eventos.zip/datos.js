module.exports = class Eventos {

    constructor(db){
        this.db = db
    }
    getEvento() {
        return this.db.any("SELECT * FROM evento ")
            .then(function (data) { // el them tiene una promesa
                return(data)
            })
            .catch(function (error) {
                return ({ error })
            });
    }
    getEventoById(id) {
        return this.db.any("SELECT * FROM evento WHERE id_evento="+id)
        .then(function (data) { // el them tiene una promesa
                return(data)
            })
            .catch(function (error) {
                return ({ error })
            });
    }
    setEvento(evento) {
        return this.db.none("INSERT INTO evento (fecha_evento,nombre_evento,lugar_evento,descripcion_evento,numero_personas_evento) VALUES ($<evento.fecha_evento>,$<evento.nombre_evento>,$<evento.lugar_evento>,$<evento.descripcion_evento>,$<evento.numero_personas_evento>)",{evento})
    }
    updateEvento(evento){
        return this.db.none("UPDATE evento SET nombre_evento= $<evento.nombre_evento>  where id_evento = $<evento.id_evento>",{evento})
    }
    deleteEvento(id){
        return this.db.none("DELETE FROM evento WHERE id_evento ="+id)
        .then(function (data) { // el them tiene una promesa
                return(data)
            })
            .catch(function (error) {
                return ({ error })
            });
    }

}